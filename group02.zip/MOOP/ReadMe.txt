------------------------------------------  
    Applied Computational Intelligence
        Second Project Report

            Authors(Group 2)
        Diogo Araújo (93906)
        Diogo Ribeiro (102277)
-------------------------------------------


First: 
Due to the large number of study cases the group decided to
make a script for each study case.

Run the scripts:

(1) Make sure you are in the MOOP directory
(2) Run each script (e.g. python WHCentral_Multi_50.py)
(3) The result should be something like: 

Mean cost: 524576.3333333334
Mean dist: 1090.7666666666667

Min Cost = (420630.0,963.0)
Min Dist = (420630.0,963.0)

************* Show plot for the pareto curve **************

************* Show plot for the hypervolume curve **************

Note:

After runing ALL the WHCentral_Multi_xx.py scripts 
You can run the plots_HyperVolume.py and plots_Pareto.py
They will show the junction of the three cases.

Note: You can check all the work developed by the group during
      the hole project in: https://github.com/diogojpa99/CInt_Project2