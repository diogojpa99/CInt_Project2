In the respective directories you will find the respective ReadMe file
With the respective orientations how to run the programs.