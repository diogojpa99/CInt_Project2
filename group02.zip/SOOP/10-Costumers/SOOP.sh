#!/bin/zsh

echo '-------------------------------------------------------------'
echo '---------------------- 10 Customers -------------------------'
echo '-------------------------------------------------------------'


echo '------------------- WHCentral_OrdFile -----------------------'
python WHCentral_OrdFile.py 
echo '------------------- WHCentral_Ord50 -------------------------'
python WHCentral_Ord50.py 
echo '------------------- WHCorner_OrdFile ------------------------'
python WHCorner_OrdFile.py 
echo '------------------- WHCorner_Ord50  -------------------------'
python WHCorner_Ord50.py 

python plots.py 