import numpy as np
import matplotlib.pyplot as plt


################### Imports ######################

SOP10Cent50 = np.load('WHCentral_Ord50best.npy')
SOP10CentOrd = np.load('WHCentral_OrdFilebest.npy')
SOP10Corn50 = np.load('WHCorner_Ord50best.npy')
SOP10CornOrd = np.load('WHCorner_OrdFilebest.npy')

#################### Plots #######################

plt.plot(SOP10Cent50, label = 'WHCentral_Ord50')
plt.plot(SOP10CentOrd, label = 'WHCentral_OrdFile')
plt.plot(SOP10Corn50, label = 'WHCorner_Ord50')
plt.plot(SOP10CornOrd, label = 'WHCorner_OrdFile')
plt.xlabel('#Generations')
plt.ylabel('Total Distance for the best run')
plt.legend(loc='upper right')
plt.title('Convergence Curve for 30 customers')
plt.show()