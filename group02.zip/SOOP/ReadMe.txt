------------------------------------------  
    Applied Computational Intelligence
        Second Project Report

            Authors(Group 2)
        Diogo Araújo (93906)
        Diogo Ribeiro (102277)
-------------------------------------------


First: 
Due to the large number of study cases, the group decided to split the problem
into folders. Each folder contains the scripts that solve each case for the three 
different situations ( #Customers = 10, 30 and 50).

Run the scripts:

(1) Go to the respective folder (e.g. '50-Costumers')
(2) run the SOOP.sh script (you can use the command: sh SOOP.sh)
(3) The result should be something like:

-------------------------------------------------------------
---------------------- 50 Customers -------------------------
-------------------------------------------------------------
------------------- WHCentral_OrdFile -----------------------
MEAN: 1141.7
STD: 64.64990332552709
------------------- WHCentral_Ord50 -------------------------
MEAN: 1066.7333333333333
STD: 59.01747387191545
------------------- WHCorner_OrdFile ------------------------
MEAN: 1283.3333333333333
STD: 66.62798878015822
------------------- WHCorner_Ord50  -------------------------
MEAN: 1204.5
STD: 68.44352903428246

************* Show plot of the four study cases **************


Where:
MEAN: Mean result over the 30 runs
STD: STD result over the 30 runs


Note: You can check all the work developed by the group during
      the hole project in: https://github.com/diogojpa99/CInt_Project2